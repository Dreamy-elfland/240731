(function(){

  if(!window.csInitIsLoad) {
    window.jQuery&&window.jQuery.ajax({
      url:'/api/ecode/sync',
      dataType:'json',
      success:function(r) {
        if (r.api_status && r._data) {
          var val = r._data;
            if (window.localStorage) {
              var key = 'ecode_params';
              if (typeof r === 'object') {
                try {
                    window.localStorage[key] = JSON.stringify(val);
                }catch(e) {
                    window.localStorage[key] = "";
                }
              } else {
                window.localStorage[key] = val;
              }
          }
        }
      }
    });
    var tail = "";
    if (!window.localStorage.ecodeStaticCache || (window.localStorage.ecodeStaticCache && window.localStorage.ecodeStaticCache === "y"))
      tail = "?v=" + Math.random().toString().slice(-6);
    document.write("<script type=\"text/javascript\" src=\"/cloudstore/dev/init.js" + tail + "\"></script>");
    document.write("<link rel=\"stylesheet\" href=\"/cloudstore/dev/init.css" + tail + "\" type=\"text/css\" />");
    window.csInitIsLoad = true;
  }

})();